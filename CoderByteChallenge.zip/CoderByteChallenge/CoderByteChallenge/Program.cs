﻿using System;

namespace CoderByteChallenge
{
    class Program
    {
        
        static void Main(string[] args)
        {
            ProblemALG005b problem = new ProblemALG005b(9, 30, 7);
            Console.WriteLine("Hello World!");

            problem.Logic();
        }
    }

    
}
