﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoderByteChallenge
{
    public class ProblemALG005b
    {
        int sizeOfShape, xCentre, yCentre;
        string[,] image = new string[25, 79];

        public ProblemALG005b(int sizeOfShape, int xCentre, int yCentre) //6,30,9
        {
            this.sizeOfShape = sizeOfShape;
            this.xCentre = xCentre;
            this.yCentre = yCentre;
        }

        public void PopulateBackground()
        {
            for (int i = 0; i < 25; i++)
            {
                for (int j = 0; j < 79; j++)
                {
                    image[i, j] = "=";
                }
            }
        }

        public void AddShape()
        {
            //Center
            int centerX = xCentre - 1;
            int centerY = yCentre - 1;
            //Corners
            int rightEnd = centerX + sizeOfShape;
            int leftEnd = centerX - sizeOfShape;
            int topEnd = centerY - sizeOfShape;
            int bottomEnd = centerY + sizeOfShape;

            //Addcenter
            if(centerY <= 25 && centerX <= 79 && centerY >=0 && centerX >= 0)
            {
                image[centerY, centerX] = "$";
            }
            
            //Add Corners
            if (centerY <= 25 && rightEnd -1 <= 79 && centerY >= 0 && centerX >= 0)
            {
                image[centerY, rightEnd - 1] = "$";
            }
            if (centerY <= 25 && leftEnd + 1 <= 79 && centerY >= 0 && centerX >= 0)
            {
                image[centerY, leftEnd + 1] = "$";
            }
            if (topEnd+1 <= 25 && centerX <= 79 && centerY >= 0 && centerX >= 0)
            {
                image[topEnd + 1, centerX] = "$";
            }
            if (bottomEnd-1 <= 25 && centerX <= 79 && centerY >= 0 && centerX >= 0)
            {
                image[bottomEnd - 1, centerX] = "$";
            }
            
            
            
            

            //CenterToEdgeDist
            int centerToTopDist = centerY - topEnd -1;
            int centerToBottomDist = bottomEnd - 1 - centerY;
            int itteratedNum = 1;
            
            for (int i = 0; i < centerToTopDist; i++)
            {
                //At  next line center coords ++ distamce from middle
                //right end move one extra over
                if(topEnd + 1 + itteratedNum <=25 && centerX + itteratedNum <= 79 && topEnd + 1 + itteratedNum >= 0 && centerX + itteratedNum >= 0)
                {
                    image[topEnd + 1 + itteratedNum, centerX + itteratedNum] = "$";
                }
                
                if(topEnd + 1 + itteratedNum <= 25 && centerX - itteratedNum <= 79 && topEnd + 1 + itteratedNum >= 0 && centerX - itteratedNum >= 0)
                {
                    image[topEnd + 1 + itteratedNum, centerX - itteratedNum] = "$";
                }
                
                
                itteratedNum++;

            }
            itteratedNum = 1;
            for (int i = 0; i < centerToBottomDist; i++)
            {
                //At  next line center coords ++ distamce from middle
                //right end move one extra over
                image[bottomEnd - 1 - itteratedNum, centerX + itteratedNum] = "$";
                image[bottomEnd - 1 - itteratedNum, centerX - itteratedNum] = "$";
                itteratedNum++;

            }


        }

        public void AddNumbers()
        {
            //Columns
            for (int i = 0; i < 25; i++)
            {
                if(i == 9)
                {
                    image[i, 0] = "1";
                }
                else if(i == 19)
                {
                    image[i, 0] = "2";
                }
                
            }
            int number = 9;
            int columnNumber = 0;
            //Rows
            for (int i = 0; i < 25; i++)
            {
                for (int j = 0; j < 79; j++)
                {
                    if (j == number)
                    {
                        columnNumber++;
                        image[i, j] = Convert.ToString(columnNumber);
                        number += 10;
                    }
                    
                }
                columnNumber = 0;
                number = 9;

            }

        }

        public void DisplayImage()
        {
            string formattedImage = "";
            for (int i = 0; i < 25; i++)
            {
                for (int j = 0; j < 79; j++)
                {
                    formattedImage += image[i, j];
                }

                formattedImage += "\n";
            }
            Console.Write(formattedImage);
        }

        public void Logic()
        {
            PopulateBackground();
            AddNumbers();
            AddShape();
            DisplayImage();
        }


    }
}
